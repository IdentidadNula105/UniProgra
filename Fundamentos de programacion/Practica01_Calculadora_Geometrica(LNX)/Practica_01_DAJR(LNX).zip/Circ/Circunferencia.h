#ifndef Circunferencia
#define Circunferencia
void MenuC();
float EcOR(float r);
void EcCR(float c1x, float c1y, float r);
void EcCP(float c1x, float c1y, float p1x, float p1y, float r);
void EcPPD(float p1x, float p1y, float p2x, float p2y, float r);
int ContinuarCir();
#endif
