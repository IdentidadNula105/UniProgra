#ifndef CoorPolar
#define CoorPolar
void MenuCP();
struct Coordenada;
void ConRP();
void ConPR();
int ContinuarCP();
#endif