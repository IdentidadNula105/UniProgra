gcc main.c LR/LineaRecta.c Circ/Circunferencia.c Cp/CoorPolar.c -o Calculadora
./Calculadora
