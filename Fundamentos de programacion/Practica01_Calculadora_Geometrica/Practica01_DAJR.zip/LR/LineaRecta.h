#ifndef LineaRecta
#define LineaRecta
void MenuLR();
void EcMP(float m, float p1x, float p1y);
void EcPP(float p1x, float p1y, float p2x, float p2y);
float DisPP(float p1x, float p1y, float p2x, float p2y);
void PunM(float p1x, float p1y, float p2x, float p2y);
void TriPA(float p1x, float p1y, float p2x, float p2y, float p3x, float p3y);
int ContinuarLR();
#endif